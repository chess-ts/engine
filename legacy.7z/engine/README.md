# engine
The chess.ts engine

## Tech Stack

| Element | Tech |
| - | - |
| Engine | TypeScript |
| Site | Next.js |


## Engine TODO

- [ ] Opérations entre les bitboards
  - [x] Constantes
    - [x] Bitboard vide
    - [x] Bitboard univers
  - [ ] Opérations sur les bits
    - [x] Intersection (a & b)
    - [x] Union (a | b)
    - [x] Complément (a ~ b)
    - [x] Complément relatif (a & !b)
    - [x] Implication (~a | b)
    - [x] XOR (a ^ b)
    - [x] Equivalence (~(a ^ b))
    - [ ] Majorité (a & b) | (a & c) | (b & c)
    - [x] Greater One (a & b) | (a & c) | (b & c)
  - [ ] Shifting
    - [ ] Une case
    - [ ] Rotations
    - [ ] Shifts multiples
    - [ ] Indexage (nb <=> bit)
    - [ ] Déplacements et captures
    - [ ] Echanger des bits
  - [ ] Opérations arithmétiques
    - [ ] Addition
    - [ ] Soustraction
    - [ ] Complément à 2
    - [ ] Bit le moins significatif
    - [ ] 0 le moins significatif
    - [ ] 1 le plus significatif
    - [ ] Multiplication
    - [ ] Division
    - [ ] Modulo
- [ ] Population en bits
  - [ ] Vide ou seul
    - [ ] Bitboards vides
    - [ ] Bitboards avec un seul bit à 1
  - [ ] Méthode SWAR ("diviser pour mieux règner")
    - [ ] Duo de bits
    - [ ] Blocs de bits (bytes)
    - [ ] Addiction des bytes
    - [ ] popCount (combinaison du dessus)
  - [ ] Autres outils divers
    - [ ] Cardinalité de plusiseurs bitboards
    - [ ] Distance de Hamming (nombre de bits correspondants)
- [ ] BitScan
  - [ ] BitScan forward (1 le moins signifiant)
  - [ ] BitScan reversed (1 le plus signifiant)
- [ ] Retourner, miroir et rotations
  - [ ] Bitboard complet
    - [ ] Retourner et miroir
      - [ ] Vertical
      - [ ] Horizontal
      - [ ] Généralisé
      - [ ] Diagonale (/, a1 - h8)
      - [ ] Anti-diagonale (\\, a8 - h1)
    - [ ] Rotations
      - [ ] 180° (inversage de bits)
      - [ ] 90° horaire
      - [ ] 90° anti-horaire
    - [ ] Pseudo-rotations
	  - [ ] 45° horaire
	  - [ ] 45° anti-horaire
  - [ ] Rank, file ou diagonale
    - [ ] Retourner sur l'anti-diagonale
      - [ ] File à rank
      - [ ] Rank à file
    - [ ] Retourner sur la diagonale
      - [ ] File à rank
    - [ ] Diagonales à ranks
    - [ ] Mirroir horizontal
- [ ] Algorithmes de remplissage
  - [ ] Pions
    - [ ] Remplissage avant
    - [ ] Remplissage arrière
    - [ ] Remplissage file
  - [ ] Portées
    - [ ] Portées des pions
    - [ ] Portées d'attaque
  - [ ] Remplissage directionnel
  - [ ] Remplissage de cases
    - [ ] Sud
    - [ ] Nord
    - [ ] Est
    - [ ] Ouest
    - [ ] Sud-Est
    - [ ] Sud-Ouest
    - [ ] Nord-Est
    - [ ] Nord-Ouest
  - [ ] Remplissage à occlusion (raycasting)
	- [ ] Sud
	- [ ] Nord
	- [ ] Est
	- [ ] Ouest
	- [ ] Sud-Est
	- [ ] Sud-Ouest
	- [ ] Nord-Est
	- [ ] Nord-Ouest
  - [ ] Attaques par rayons (occlusion + 1 pour attaque)
  - [ ] Rayons en général
    - [ ] Remplissage à occlusion
    - [ ] Shift directionnel
    - [ ] Attaques par slide (rayons + 1 pour attaque)
    - [ ] Shift offsets (décalage de cases) {9, 1,-7,-8,-9,-1, 7, 8}
- [ ] Mouvements de pièces
  - [ ] Pions
    - [ ] Déplacements (+ double)
      - [ ] Dépendance à la couleur
      - [ ] Possibilité de déplacer (+ double)
      - [ ] Généralisé (pions, vide, couleur)
    - [ ] Captures
      - [ ] Toutes cases noEaOne
      - [ ] Toutes cases noWeOne
      - [ ] Combinaison
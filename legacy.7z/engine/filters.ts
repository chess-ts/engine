export default {
	Pawn: 
}